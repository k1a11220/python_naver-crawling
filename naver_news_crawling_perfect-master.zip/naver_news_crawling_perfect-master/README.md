# naver_news_crawling_perfect
네이버 뉴스 전문 크롤링


- 네이버 뉴스의 전문을 크롤링할 수 있다.
- 그러나 네이버 뉴스에 등록된 기사만 가능 ( 크롤링 결과 갯수가 적다. )
- 참고했던 블로그  
http://ahnyuk.blogspot.com/2018/07/python.html
